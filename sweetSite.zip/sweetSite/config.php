<?php 
$conn = mysqli_connect("localhost","root","","sweet");
$conn -> set_charset("utf8");
   
?>